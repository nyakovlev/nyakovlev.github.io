from threading import Lock


def create_context(parent_contexts=None, parent_attrs=None, parent_vars=None):
    # TODO: consider adding a keyed cache for more granular refresh.

    attrs = {} if parent_attrs is None else {**parent_attrs}
    sub_contexts = []
    suspended = []
    escapes = {}
    vars = {} if parent_vars is None else {**parent_vars}
    lock = Lock()

    def escape(func):
        escapes[func.__name__] = func

    class _Context:
        def __getattr__(self, key):
            if key in escapes: return escapes[key]
            if key in attrs: return attrs[key]
            raise KeyError(key)

        def __setattr__(self, key, value):
            attrs[key] = value
    
    self = _Context()

    @escape
    def suspend(handle):
        suspended.append(handle)
    
    @escape
    def release():
        with lock:
            for sub_ctx in reversed(sub_contexts):
                sub_ctx.release()
            sub_contexts.clear()
            for handle in reversed(suspended):
                handle()
            suspended.clear()
            vars.clear()
    
    @escape
    def destroy():
        release()
        if parent_contexts is not None:
            parent_contexts.remove(self)
    
    @escape
    def sub_ctx():
        sub_ctx = create_context(sub_contexts, attrs, vars)
        sub_contexts.append(sub_ctx)
        return sub_ctx
    
    @escape
    def store(key, value):
        vars[key] = value
    
    @escape
    def lookup(key):
        if key in vars: return vars[key]
        if "frame" in attrs:
            frame = attrs["frame"]
            if key in frame.f_locals: return frame.f_locals[key]
            if key in frame.f_globals: return frame.f_globals[key]
        raise KeyError(key)
    
    escapes["vars"] = vars

    return self
