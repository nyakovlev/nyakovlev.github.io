import asyncio
import json
from threading import Thread
import sys
import traceback
from bson.objectid import ObjectId

from .misc import Handler
from .misc import Promise


class Remote:
    def __init__(self, wsock, obj) -> None:
        self.wsock = wsock
        self.obj = obj
        self.loop = None
        self.cache = {}
        self.cache_handler = Handler()
        self.inflights = {}
        self.inflight_handler = Handler()
        Thread(target=self.report_cache).start()
    
    def report_cache(self):
        import time
        while 1:
            time.sleep(5)
            print(len(self.cache), end=";", flush=True)

    async def serve(self):
        self.loop = asyncio.get_event_loop()
        async for msg in self.wsock:
            data = json.loads(msg)
            op = data["op"]
            if op == "call":

                def run_call():
                    result = None
                    try:
                        target = self.obj if data["cache_id"] is None else self.cache[data["cache_id"]]
                        for key in data["path"]: target = getattr(target, key)
                        proxies = []
                        args = [self.demodulate(v, proxies=proxies) for v in data["args"]]
                        result = {
                            "success": True,
                            "data": self.modulate(target(*args))
                        }
                        for proxy in proxies:
                            proxy.__release__()
                    except:
                        result = {
                            "success": False,
                            "error": "\n".join(traceback.format_exception(*sys.exc_info()))
                        }
                    asyncio.run_coroutine_threadsafe(
                        self.wsock.send(json.dumps({
                            "op": "return",
                            "op_id": data["op_id"],
                            "result": result
                        })),
                        self.loop
                    )
                
                Thread(target=run_call).start()

                continue
            if op == "return":
                Thread(target=self.inflights[data["op_id"]], args=(data["result"],)).start()
                continue
            if op == "release":
                del self.cache[data["cache_id"]]
                self.cache_handler.release(data["cache_id"])

    def modulate(self, obj):
        if obj is None or type(obj) in [int, str, bool, float]:
            return { "kind": "const", "value": obj }
        if isinstance(obj, ObjectId):
            return { "kind": "const", "value": str(obj) }
        if type(obj) is list:
            return {
                "kind": "list",
                "items": [self.modulate(item) for item in obj]
            }
        if type(obj) is dict:
            return {
                "kind": "dict",
                "fields": {k: self.modulate(v) for k, v in obj.items()}
            }
        is_proxy = False
        try:
            if obj.__proxy__ == True: is_proxy = True
        except: pass
        if is_proxy:
            return {
                "kind": "cached",
                "cache_id": obj.__cache_id__,
                "path": obj.__path__
            }
        cache_id = self.cache_handler.acquire()
        self.cache[cache_id] = obj
        return { "kind": "remote", "cache_id": cache_id }

    def demodulate(self, data, proxies=None):
        kind = data["kind"]
        if kind == "const": return data["value"]
        if kind == "list": return [self.demodulate(item) for item in data["items"]]
        if kind == "dict": return {k: self.demodulate(v) for k, v in data["fields"].items()}
        if kind == "cached":
            value = self.cache[data["cache_id"]]
            for key in data["path"]: value = getattr(value, key)
            return value
        if kind == "remote":
            proxy = self.get_proxy(data["cache_id"])
            if proxies is not None: proxies.append(proxy)
            return proxy
    
    def get_proxy(self, cache_id, path=None):
        if path is None: path = []
        holds = 1  # proxy has one autmatic hold on creation

        def acquire():
            nonlocal holds
            holds += 1

        def release():
            nonlocal holds
            holds -= 1
            if holds <= 0:
                asyncio.run_coroutine_threadsafe(
                    self.wsock.send(json.dumps({
                        "op": "release",
                        "cache_id": cache_id
                    })),
                    self.loop
                )
        
        escapes = {
            "__proxy__": True,
            "__path__": path,
            "__cache_id__": cache_id,
            "__acquire__": acquire,
            "__release__": release
        }

        class _Proxy:
            def __getattr__(_self, key):
                if key in escapes: return escapes[key]

                return self.get_proxy(cache_id, path=[*path, key])
            
            def __call__(_self, *args):
                margs = [self.modulate(v) for v in args]
                inflight_handle = self.inflight_handler.acquire()
                promise = Promise()

                def resolve(response):
                    del self.inflights[inflight_handle]
                    self.inflight_handler.release(inflight_handle)
                    if response["success"]:
                        promise.resolve(self.demodulate(response["data"]))
                        return
                    err_str = response["error"]
                    promise.reject(f"Error on remote endpoint: {err_str}")

                self.inflights[inflight_handle] = resolve

                asyncio.run_coroutine_threadsafe(
                    self.wsock.send(json.dumps({
                        "op": "call",
                        "op_id": inflight_handle,
                        "cache_id": cache_id,
                        "path": path,
                        "args": margs
                    })),
                    self.loop
                )

                return promise.join()
        
        return _Proxy()
