from flask import Flask, request
import asyncio
from websockets.server import serve
from threading import Thread
import os
from pathlib import Path
from uuid import uuid1
import ast
from pathlib import Path

from .remote import Remote
from .misc import Endpoint
import inspect
from . import watch
from . import gui_ast
from .context import create_context


local_path = Path(__file__).parent.absolute()


class WebServer:
    def __init__(self, address="0.0.0.0", port=80) -> None:
        self.address = address
        self.port = port
        self.clients = []
        self.sock_port = 29000 + port
        self.app = Flask(str(uuid1()))
        self.app.route("/", methods=["GET"])(self.index)
        self.app.route("/file/<file_id>", methods=["GET"])(self.get_file)
        self.files = {}
        self.spec = None
        self.spec_frame = None
        self.spec_ast = None
        self.threads = []

    def start(self):
        return [self.start_http_server(), self.start_socket_server()]

    def run(self):
        for t in self.start():
            t.join()

    def run_http_server(self):
        self.app.run(host=self.address, port=self.port)
    
    def start_http_server(self):
        t = Thread(target=self.run_http_server)
        t.start()
        return t
    
    def index(self):
        with open(os.path.join(local_path, "index.html")) as f:
            return f.read()

    def start_socket_server(self):
        t = Thread(target=self.run_socket_server)
        t.start()
        return t

    def run_socket_server(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        asyncio.run(self.serve_socket())
    
    async def serve_socket(self):
        print(f"Running WebSocket server on {self.address}:{self.sock_port}")
        async with serve(self.on_connect, self.address, self.sock_port):
            await asyncio.Future()
    
    async def on_connect(self, sock):

        class _ClientApi:
            def bind_client(self_2, client):

                ctx = create_context()
                ctx.client = client
                ctx.frame = self.spec_frame
                ctx.div = client.body
                ctx.add_file = self.add_file

                client.__acquire__()  # acquire client, since it is neded for subscription updates
                
                @self.spec_ast.subscribe
                def on_spec_ast(spec_ast):
                    # Option 1: Run spec through GUI syntax. Results in beautiful client code, but requires parser to already be developed.
                    # Hoping that @raw decorator gets the best of both worlds by providing an escape back to non-gui AST.
                    gui_ast.render_page(spec_ast, ctx)

                    # # Option 2: Run spec as-is. Makes for some ugly client code, but it should be able to accommodate all features off the bat.
                    # spec_ast.decorator_list = []  # Prevents rerun of decorators
                    # spec_code = ast.unparse(spec_ast)
                    # func_locals = {**self.spec_frame.f_locals}
                    # exec(spec_code, self.spec_frame.f_globals, func_locals)
                    # spec = func_locals[self.spec.__name__]
                    # spec(ctx)
                
                # NOTE: Running on_spec_ast() now unsubscribes from the AST.
                # TODO: figure out how unsubscribing would work, if ever.


        client = Remote(sock, obj=_ClientApi())
        self.clients.append(client)
        await client.serve()
    
    def apply_spec(self, spec, frame):
        self.spec = spec
        self.spec_frame = frame

        self.spec_ast = Endpoint(ast.parse(inspect.getsource(spec)).body[0])
        @watch.func_ast(spec)
        def on_change(func_ast):
            self.spec_ast.publish(func_ast)
    
    def host(self, page):
        self.apply_spec(page.spec, page.frame)
        for t in self.start():
            self.threads.append(t)

    def join(self):
        for t in self.threads:
            t.join()
    
    def add_file(self, path):

        def set_handler(handler):
            self.files[path] = handler

        return set_handler
    
    def get_file(self, file_id):
        return self.files[file_id]()


def gui(spec):
    frame = inspect.currentframe().f_back

    class _Gui:
        def __init__(self) -> None:
            self.spec = spec
            self.frame = frame
            self.dir = Path(inspect.getfile(spec)).parent.absolute()

    return _Gui()


def expr(obj):
    # Tries to wrap an ephemeral expression; i.e., the return value goes nowhere.
    # So, try to release anything returned; can be a mix of simple and complex data.
    if obj is None or type(obj) in [int, str, bool, float]: return
    if type(obj) is list:
        for item in obj: expr(item)
    if type(obj) is dict:
        for item in obj.values(): expr(item)
    try:
        if obj.__proxy__:
            obj.__release__()
    except: pass
