from pymongo import MongoClient
from threading import Thread, Lock
from bson.objectid import ObjectId


# TODO!!! Make sure API has short timeouts or otherwise clarifies when we are waiting for a response.
# NOTE: While this is most plainly designed to have only one object per collection, it is possible to have coexistence as long as their entries never collide.
#  Always filtering by a session ID or something similar should ensure this - it is important to prevent a single bottleneck and excessive event propagation.


MONGO_ADDRESS = "mongodb://labvm-1:27017"


mongo_client = MongoClient(MONGO_ADDRESS)
db = mongo_client.dev


class Entry:
    def __init__(self, key, handle) -> None:
        self.key = key
        self.handle = handle
    
    def update(self, doc):
        pass

    def delete(self):
        pass


class LiveCollectionBinding:
    def __init__(self, live_collection, assign, insert, window_size, doc_filter, doc_sort) -> None:
        self.live_collection = live_collection
        self._assign = assign
        self._insert = insert
        self.window_size = window_size
        self.doc_filter = doc_filter
        self.doc_sort = doc_sort
        self.entries = {}

    def unbind(self):
        self.live_collection.unbind(self)

    # TODO: Improve functionality of the bound functions to re-filter, re-sort, push out elements, etc. (i.e. simulate a re-)
    # TODO: Add calls within the binding object to adjust filter and window size
    # TODO: Add calls and other logic to perform paging, i.e. sliding a window.

    def adjust_query(self, window_size, doc_filter, doc_sort):
        self.window_size = window_size
        self.doc_filter = doc_filter
        self.doc_sort = doc_sort
        self.live_collection.adjust_query(self, window_size, doc_filter, doc_sort)

    def assign(self, docs):
        # TODO: Consider how subsequent assign() ops would invoke the delete parameter.
        for doc, entry in zip(docs, self._assign(docs)):
            key = str(doc["_id"])
            self.entries[key] = entry

    def insert(self, key, doc):
        # NOTE: For the most part, sort and filter should not require re-query.
        # re-query becomes crucial when we are updating existing entries - 
        # if anything hits the edge of sort or falls off the filter, re-query is needed to determine (potential) replacements.
        # This will require re-introducing an intermediate Entry object in this class, since extra facilitation will be needed.
        if self.doc_filter is not None:
            # TODO: return early if filter does not include new entry
            raise Exception("TODO: filtering")
        if self.doc_sort is None:
            self.entries[key] = self._insert(doc)
        else:
            raise Exception("TODO: sorting")

    def put(self, key, doc):
        if key in self.entries:
            self.entries[key].update()

    def delete(self, key):
        if key in self.entries:
            self.entries[key].delete()
            del self.entries[key]


# TODO: consider the second arg of collection.find(), which lets you pull only certain fields from an object.
#  Maybe it would help make things more efficient?


class LiveCollection:
    def __init__(self, collection) -> None:
        self.collection = collection
        self.lock = Lock()
        # NOTE: window size and doc filter are just the global default; each binding will be able to configure their own value.
        self.bindings = []
    
    def __live_collection__(self):
        return True
    
    def query(self, window_size, doc_filter, doc_sort):
        find_args = [] if doc_filter is None else [doc_filter]
        result = self.collection.find(*find_args)
        if doc_sort is not None:
            result = result.sort(doc_sort)
        if window_size is not None:
            result = result.limit(window_size)
        return result
    
    def adjust_query(self, binding, window_size, doc_filter, doc_sort):
        with self.lock:
            binding.assign(self.query(window_size, doc_filter, doc_sort))
    
    def bind(self, assign, insert, window_size=10, doc_filter=None, doc_sort=None):
        with self.lock:
            binding = LiveCollectionBinding(self, assign, insert, window_size, doc_filter, doc_sort)
            self.bindings.append(binding)
            binding.assign(self.query(window_size, doc_filter, doc_sort))
            return binding

    def unbind(self, binding):
        with self.lock:
            if binding in self.bindings:
                self.bindings.remove(binding)

    def insert(self, doc):
        with self.lock:
            resp = self.collection.insert_one(doc)
            key = resp.inserted_id
            for binding in self.bindings:
                Thread(target=binding.insert, args=(key, doc)).start()
            return key

    def update(self, key: str, doc):
        with self.lock:
            self.collection.update_one({"_id": ObjectId(key)}, doc)
            for binding in self.bindings:
                Thread(target=binding.update, args=(key, doc)).start()

    def delete(self, key: str):
        with self.lock:
            self.collection.delete_one({"_id": ObjectId(key)})
            for binding in self.bindings:
                Thread(target=binding.delete, args=(key)).start()


# print("entries:")
# for doc in coll.find():
#     print(doc)
# print("done")


# coll = LiveCollection(db.test)
