import re
import shortuuid
import ast
import inspect
import os
from flask import Response

from .elements import Styled, Div
from . import watch


def t(obj): return obj.__class__.__name__


def expr(obj):
    # Tries to wrap an ephemeral expression; i.e., the return value goes nowhere.
    # So, try to release anything returned; can be a mix of simple and complex data.
    if obj is None or type(obj) in [int, str, bool, float]: return
    if type(obj) is list:
        for item in obj: expr(item)
    if type(obj) is dict:
        for item in obj.values(): expr(item)
    try:
        if obj.__proxy__:
            obj.__release__()
    except: pass


def render_page(spec_ast, ctx):
    """
    NOTE: render_page expects ctx.div to be set to a div.
    This function does not create a div to return to you!
    It takes an existing div and augments it.
    This makes a little less sense for a component model, but it helps with building the root page in document.body;
    It lets you augment document.body directly - gives you more of a fullscreen access if needed.
    """

    ctx.release()
    expr(ctx.client.assign(ctx.div, ["innerHTML"], ""))
    for dec_ast in reversed(spec_ast.decorator_list):
        if t(dec_ast) == "Name":
            dec_name = dec_ast.id
            if dec_name == "gui": continue
            dec = None
            try:
                dec = ctx.lookup(dec_name)
            except KeyError: pass
            if dec is not None:
                if inspect.isclass(dec):
                    if issubclass(dec, Styled.Div):
                        apply_style(ctx, ctx.div, dec)
    for obj in spec_ast.body:
        handle_div_component(obj, ctx)


def kebabize(name):
    return re.sub(r'(?<!^)(?=[A-Z])', '-', name).lower()


def is_style_attr(key):
    if key.startswith("_"): return False
    if key == "hover": return False
    return True


def get_style_attrs(style_class):
    attrs = [f"{kebabize(k)}: {getattr(style_class, k)}" for k in dir(style_class) if is_style_attr(k)]
    attrs_str = "; ".join(attrs)
    return attrs_str


def apply_style(ctx, div, style_class):
    class_name = "cls" + shortuuid.uuid()
    ctx.client.assign(div, ["className"], class_name)
    style = ctx.client.document.createElement("style")
    ctx.suspend(style.__release__)
    ctx.client.assign(style, ["type"], "text/css")
    style_text = f".{class_name} {{{get_style_attrs(style_class)}}}"
    if hasattr(style_class, "hover"):
        style_text += f"\n.{class_name}:hover {{{get_style_attrs(style_class.hover)}}}"
    ctx.client.assign(style, ["innerHTML"], style_text)
    expr(div.appendChild(style))


def handle_expr(obj, ctx):
    element = get_renderable(obj.value, ctx)
    if element is not None:
        expr(ctx.div.appendChild(element))
    return


def handle_function_def(obj, ctx):
    for dec_ast in reversed(obj.decorator_list):
        if t(dec_ast) == "Name":
            dec_name = dec_ast.id
            if dec_name == "gui": continue
            if dec_name == "raw":
                # Runs spec without GUI syntax. Useful for new or odd features that don't have a syntax defined yet.
                obj.decorator_list = []
                spec_code = ast.unparse(obj)
                func_locals = {**ctx.frame.f_locals, **ctx.vars}
                exec(spec_code, ctx.frame.f_globals, func_locals)
                spec = func_locals[obj.name]
                spec(ctx.sub_ctx())
                continue
            if dec_name == "click":
                print("TODO: handle on-client click listener")
                continue
            dec = None
            try:
                dec = ctx.lookup(dec_name)
            except KeyError: pass
            if dec is not None:
                if inspect.isclass(dec):
                    if issubclass(dec, Div):
                        div = ctx.client.document.createElement("div")
                        ctx.suspend(div.__release__)
                        if issubclass(dec, Styled.Div):
                            apply_style(ctx, div, dec)
                        sub_ctx = ctx.sub_ctx()
                        sub_ctx.div = div
                        for item in obj.body:
                            handle_div_component(item, sub_ctx)
                        
                        expr(ctx.div.appendChild(div))
                        continue


def handle_for(obj, ctx):
    items = ctx.lookup(obj.iter.id)
    item_name = obj.target.id
    try:
        items.__live_collection__()
    except:
        raise Exception("TODO: handle non-live loop")
    
    def insert(doc):
        iter_ctx = ctx.sub_ctx()

        # TODO: clean up this div wrapping.
        # It creates an intermediate div issue where there may be a disconnect between the parent and child css rules.
        # Probably need to find a way to dissolve the per-iter div wrapper without harming order of resulting divs.
        # TODO: consider how reordering would look in a love collection.
        iter_div = ctx.client.document.createElement("div")
        ctx.suspend(iter_div.__release__)
        iter_ctx.div = iter_div
        expr(ctx.div.appendChild(iter_div))

        def update(new_doc):
            iter_ctx.store(item_name, new_doc)
            for sub_obj_ast in obj.body:
                handle_div_component(sub_obj_ast, iter_ctx)

        update(doc)
        
        class _Entry:
            def update(self, new_doc):
                # TODO: Create a version of page that just handles .body, not requiring a FunctionDef body.
                # Then, get rid of the release() here and rely on the body to decide what to release.
                iter_ctx.release()

                @iter_ctx.suspend
                def clear():
                    iter_ctx.client.assign(iter_div, ["innerHTML"], "")

                update(new_doc)

            def delete(self):
                iter_div.remove()
                iter_ctx.destroy()
        
        return _Entry()

    def assign(docs):
        return [insert(doc) for doc in docs]
    
    binding = items.bind(assign, insert)
    ctx.suspend(binding.unbind)


def handle_assign(obj, ctx):
    value = get_value(obj.value, ctx)
    for target_ast in obj.targets:
        ctx.store(target_ast.id, value)  # Assumes Name


def get_value(obj, ctx):
    obj_type = t(obj)
    if obj_type == "Constant":
        return obj.value
    if obj_type == "Name":
        return ctx.lookup(obj.id)
    if obj_type == "Subscript":
        return get_value(obj.value, ctx)[get_value(obj.slice, ctx)]
    if obj_type == "FormattedValue":
        return f"{get_value(obj.value, ctx)}"
    raise TypeError(obj_type)


ast_handlers = {
    "Expr": handle_expr,
    "FunctionDef": handle_function_def,
    "For": handle_for,
    "Assign": handle_assign,
}


def handle_div_component(obj, ctx):
    obj_type = t(obj)
    if obj_type in ast_handlers: return ast_handlers[obj_type](obj, ctx)
    raise KeyError(t(obj))


def get_renderable(obj, ctx):
    obj_type = t(obj)
    if obj_type == "Constant":
        if type(obj.value) is str:
            v = ctx.client.document.createTextNode(obj.value)
            ctx.suspend(v.__release__)
            return v
    if obj_type == "Call":
        if t(obj.func) == "Name":
            if obj.func.id == "click":
                handler_ast = obj.args[0]
                handler = ctx.lookup(handler_ast.id)  # Assumes arg is a Name
                listener = ctx.client.addEventListener(ctx.div, "click", handler)
                ctx.suspend(listener.__release__)
                ctx.suspend(listener)
                return
            if obj.func.id == "Style":
                path = obj.args[0].value

                import_name = "file-" + shortuuid.uuid() + ".css"
                @ctx.add_file(import_name)
                def load_file():
                    tmp_dir = os.getcwd()
                    os.chdir(ctx.dir)
                    with open(path, "r") as f:
                        content = f.read()
                    os.chdir(tmp_dir)
                    return Response(content, mimetype="text/css")

                style = ctx.client.document.createElement("link")
                ctx.suspend(style.__release__)
                ctx.client.assign(style, ["href"], f"file/{import_name}")
                ctx.client.assign(style, ["type"], "text/css")
                ctx.client.assign(style, ["rel"], "stylesheet")
                expr(ctx.div.appendChild(style))

                return
            if obj.func.id == "Script":
                path = obj.args[0].value

                import_name = "file-" + shortuuid.uuid() + ".js"
                @ctx.add_file(import_name)
                def load_file():
                    tmp_dir = os.getcwd()
                    os.chdir(ctx.dir)
                    with open(path, "r") as f:
                        content = f.read()
                    os.chdir(tmp_dir)
                    return Response(content, mimetype="text/javascript")

                style = ctx.client.document.createElement("script")
                ctx.suspend(style.__release__)
                ctx.client.assign(style, ["src"], f"file/{import_name}")
                ctx.client.assign(style, ["type"], "text/javascript")
                expr(ctx.div.appendChild(style))

                return
            raise Exception("TODO: handle call", obj.func.id)
        raise Exception("Non-name call")
    if obj_type == "JoinedStr":
        text = "".join([get_value(v, ctx) for v in obj.values])
        text_node = ctx.client.document.createTextNode(text)
        ctx.suspend(text_node.__release__)
        return text_node
    if obj_type == "Name":
        value = ctx.lookup(obj.id)
        if hasattr(value, "__gui__"):
            gui = value.__gui__
            cmp_div = ctx.client.document.createElement("div")
            ctx.suspend(cmp_div.__release__)
            cmp_ctx = ctx.sub_ctx()
            cmp_ctx.dir = gui.dir
            cmp_ctx.div = cmp_div
            cmp_ctx.frame = gui.frame
            @watch.func_ast(gui.spec, initialize=True)
            def on_update(func_ast):
                cmp_ctx.release()

                @cmp_ctx.suspend
                def clear():
                    cmp_ctx.client.assign(cmp_div, ["innerHTML"], "")

                for sub_obj_ast in func_ast.body:
                    handle_div_component(sub_obj_ast, cmp_ctx)

            return cmp_div
        raise Exception("Account for non-component Name")
    raise KeyError(obj_type)
