from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileModifiedEvent
import inspect
import time
import ast


def trim_indent(text: str):
    lines = text.splitlines()
    indent = min([len(line) - len(line.lstrip()) for line in lines])
    return "\n".join([line[indent:] for line in lines])


def module(path):
    
    def set_handler(handler):

        class _Watcher(FileSystemEventHandler):
            def __init__(self) -> None:
                super().__init__()
                self.last_event = None

            def on_modified(self, event):
                if not isinstance(event, FileModifiedEvent): return
                t = time.time()
                if self.last_event and t - self.last_event < 0.5: return
                self.last_event = t

                with open(path, "r") as f:
                    source = f.read()
                module_ast = ast.parse(source)
                handler(module_ast)
        
        watcher = _Watcher()
        observer = Observer()
        observer.schedule(watcher, path, recursive=False)
        observer.start()

        # TODO: consider instead returning object to manage this state
        return handler

    return set_handler


class SpecHandler:
    def match(obj): pass
    def handle(obj): pass


spec_handlers = {}


def watch(path, handler):
    if path not in spec_handlers:
        spec_handlers[path] = []

        @module(path)
        def update_ast(module_ast):
            for item_ast in module_ast.body:
                for spec_handler in spec_handlers[path]:
                    if spec_handler.match(item_ast):
                        spec_handler.handle(item_ast)
                        break
    
    spec_handlers[path].append(handler)
        

def func_ast(func, initialize=False):
    
    def set_handler(handler):
        path = inspect.getfile(func)
        name = func.__name__
        init_ast = ast.parse(trim_indent(inspect.getsource(func))).body[0]

        class _FuncHandler(SpecHandler):
            def __init__(self) -> None:
                self.old_code = ast.unparse(init_ast)

            def match(self, obj):
                if isinstance(obj, ast.FunctionDef):
                    if obj.name == name: return True
            
            def handle(self, obj):
                code = ast.unparse(obj)
                if code != self.old_code:
                    handler(obj)
                    self.old_code = code

        if initialize:
            handler(init_ast)

        watch(path, _FuncHandler())
    
    return set_handler
