# Items in this file exist only to pacify syntax highlighters.
# Actual functionality is implemented by the GUI AST parser.


class Script:
    def __init__(self, name) -> None:
        pass


class Style:
    def __init__(self, name) -> None:
        pass


class Div:
    def __init__(self, spec) -> None:
        pass
        # return spec


class Styled:
    class Div(Div): pass


def click(handler): pass
def raw(handler): pass
