from threading import Thread, Lock


# class Stasis:
#     def __init__(self) -> None:
#         self.releases = []
    
#     def suspend(self, release):
#         self.releases.append(release)
    
#     def release(self):
#         for release in reversed(self.releases): release()
#         self.releases = []


class Endpoint:
    def __init__(self, *args) -> None:
        self.initialized = len(args) > 0
        self.value = args[0] if len(args) else None
        self.subscribers = []
        self.lock = Lock()
    
    def publish(self, value):
        with self.lock:
            self.value = value
            self.initialized = True
            for subscriber in self.subscribers:
                Thread(target=subscriber, args=(value,)).start()
    
    def subscribe(self, subscriber):
        
        def unsubscribe():
            with self.lock:
                self.subscribers.remove(subscriber)

        with self.lock:
            self.subscribers.append(subscriber)
            if self.initialized:
                Thread(target=subscriber, args=(self.value,)).start()
        
        return unsubscribe


class Handler:
    def __init__(self) -> None:
        self.lock = Lock()
        self.index = 0
        self.released = []
    
    def acquire(self):
        with self.lock:
            if len(self.released): return self.released.pop()
            handle = self.index
            self.index += 1
            return handle
    
    def release(self, handle):
        with self.lock:
            if handle not in self.released:
                self.released.append(handle)
                if len(self.released) >= self.index:
                    self.released = []
                    self.index = 0


class Promise:
    def __init__(self) -> None:
        self.lock = Lock()
        self.result = None
        self.lock.acquire()

    def join(self):
        with self.lock:
            pass
        return self.result

    def resolve(self, result):
        self.result = result
        self.lock.release()
    
    def reject(self, error):
        raise Exception(error)


# def gate(*args, **kwds):

#     lock = Lock()
#     arg_cache = {}
#     kw_cache = {}

#     def ready():
#         if len(arg_cache) < len(args): return False
#         if len(kw_cache) < len(kwds): return False
#         return True

#     def set_handler(func):

#         def run():
#             arg_list = [None] * len(args)
#             for i, v in arg_cache.items():
#                 arg_list[i] = v
#             return func(*arg_list, **kw_cache)

#         def bind_arg(i, arg):

#             def assign(value):
#                 with lock:
#                     arg_cache[i] = value
#                     if ready(): return run()
            
#             arg.bind(assign=assign)
        
#         def bind_kwarg(key, arg):

#             def assign(value):
#                 with lock:
#                     kw_cache[key] = value
#                     if ready(): return run()
            
#             arg.bind(assign=assign)

#         [bind_arg(i, arg) for i, arg in enumerate(args)]
#         [bind_kwarg(k, arg) for k, arg, in kwds.items()]

#     return set_handler


# class FuncQueue:
#     def __init__(self) -> None:
#         self.lock = Lock()
#         self.queue = []
#         self.running = False
    
#     def run(self, func, *args, **kwds):

#         def set_callback(then=None):
#             with self.lock:
#                 self.queue.append((func, args, kwds, then))
#                 if not self.running:
#                     self.running = True
#                     Thread(target=self.dequeue).start()
        
#         return set_callback
    
#     def dequeue(self):
#         while True:
#             with self.lock:
#                 if not len(self.queue):
#                     self.running = False
#                     return
#                 func, args, kwds, then = self.queue.pop(0)
#                 print("dequeue", func)
#                 result = func(*args, **kwds)
#                 if then is not None:
#                     Thread(target=then, args=(result,))
